<?php
include('../helpers/conx.php');

switch ($_POST['option']) {
    case '1':
        # code...
        break;
    
    default:
        # code...
        break;
}